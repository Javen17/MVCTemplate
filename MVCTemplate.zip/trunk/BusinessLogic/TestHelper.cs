﻿namespace BusinessLogicLayer
{
	public class TestHelper
	{
		public const string TestConnectionString = "";

		public static bool IsTesting { get; set; } = true;
	}
}
