﻿namespace BusinessModel.Auth.Model
{
	public class PasswordResetRequest
	{
		public string Username { get; set; }

		public string EmailAddress { get; set; }

	}
}