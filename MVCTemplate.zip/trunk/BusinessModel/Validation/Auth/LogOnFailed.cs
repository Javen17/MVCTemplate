﻿using BusinessModel.Auth.Model;

namespace BusinessModel.Validation.Auth
{
	public class LogOnFailed : GenericValidationResult<AuthRequest>
	{
	}
}
